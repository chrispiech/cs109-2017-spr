Task:
This is a toy dataset. You may find it helpful for testing your code. You should be able to predict the test dataset (which is identical to the train dataset) with 100% accuracy.

Values:
The values are all binary. 

Column meaning:
N/A

Prediction:
N/A

Credit:
This dataset was developed by Mehran Sahami

